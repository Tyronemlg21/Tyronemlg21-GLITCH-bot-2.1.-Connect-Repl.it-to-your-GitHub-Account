const Discord = require('discord.js');
const client = new Discord.Client();
const keepAlive = require('./server.js');
const prefix = 'g';
const fs = require('fs');
const xpfile = require('./xp.json');
const Database = require("@replit/database")
const db = require('quick.db')
const canvacord = require("canvacord");
const img = "https://cdn.discordapp.com/embed/avatars/0.png";

 



client.commands = new Discord.Collection();

const commandFiles = fs
  .readdirSync('./commands')
  .filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.name, command);
}

client.on('ready', () => {
  console.log('I\'m good now');

  client.user.setPresence({ activity: { name: 'with discord.js' }, status: '' })
    .then(console.log)
    .catch(console.error);
  client.user.setActivity('ghelp', { type: 'WATCHING' })
    .then(presence => console.log(`Activity set to ${presence.activities[0].name}`))
    .catch(console.error);
 
		
});

client.on('message', message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'ping') {
    client.commands.get('ping').execute(message, args);
  } else if (command === 'beep') {
    client.commands.get('beep').execute(message, args);
  } else if (message.content === `${prefix}severinfo`) {
    client.commands.get('severinfo').execute(message, args);
  } else if (message.content === `${prefix}userinfo`) {
    client.commands.get('userinfo').execute(message, args);
  } else if (message.content === `${prefix}react`) {
    message.react('😎');
    message.react('😀');
  } else if (message.content === `${prefix}cry`) {
    client.commands.get('cry').execute(message, args);
  } else if (message.content === `${prefix}bot`) {
    message.channel.send('??? who is the? i know its not me? or im a bot? ');
  } else if (message.content === `${prefix}bot help`) {
    message.channel.send('https://discord.gg/xvUDdTSyxr');
  } else if (message.content === `${prefix}hack`) {
    const taggedUser = message.mentions.users.filter();

    message.channel.send(
      `hacking: ${taggedUser.username} sorry GLITCH bot.exe has stop working`
    );
  }
  if (message.content === `${prefix}help`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('my help commands')

      .setDescription(
        'my help commands are  \nghelp mod  \nghelp fun   \nghelp unity  '
      )
       .addFields(
        { name: '\tinvite me', value: 'https://top.gg/bot/787396792350015508' },
      )
      .addFields(
        { name: 'my website', value: 'https://GLITCH-bot-21.tyronemlg.repl.co' },
			)
			.addFields(
        { name: 'my suporrt sever', value: 'https://discord.gg/xvUDdTSyxr' },
			)

    message.channel.send(newEmbed);
		
  } if (message.content === `${prefix}help mod`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('Sorry i dont have any mod commands right now')

      .setDescription('|')

    message.channel.send(newEmbed);

  } if (message.content === `${prefix}help fun`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle(' my fun commands')

      .setDescription('gping \ngbeep \ngcry \nghack \ngreact \ngbot\ngmilk\ngmeme')
            



    message.channel.send(newEmbed);


  } if (message.content === `${prefix}faq1`) { 
  	const newEmbed = new Discord.MessageEmbed()
  	   .setColor('RANDOM')
      .setTitle('who made me?')
      .setDescription('TYRONEMLG YT made me and he got from someone namd waffle and bob is real')
      .setFooter('give credit to waffle to help me with the embed code')

    message.channel.send(newEmbed);

  } if (message.content === `${prefix}faq2`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('why dose it has so little commands for the bot')

      .setDescription('the developer of the bot is to new to coding \nso he is learning more code \nto make more cool commands')

	

    message.channel.send(newEmbed);

  } if (command === 'milk') {
    client.commands.get('milk').execute(message, args);
	
  } if (message.content === `${prefix}rand`) {
    client.commands.get('rand').execute(message, args);
		messsage.reply('sorry this command is not working')
  }if (message.content === `${prefix}8ball`) {
    client.commands.get('8ball').execute(message, args);
  } if (message.content === 'gplay') {
	message.channel.send('how abot')
	message.reply('no')
  .then(message => console.log(`Sent message: ${message.content}`))
  .catch(console.error);
	

	}  if (message.content === `${prefix}meme`) {
    client.commands.get('meme').execute(message, args);

	} if (command === 'gyesno') {
		message.channel.send(`${randomeAnswer}`);


// level up sysetem
} if(message.author.Client) return;
    var addXP = Math.floor(Math.random() * 10); //when i type addXP it will randomly choose a number between 1-10   [  Math.floor(Math.random() * 10)  ]
// lvl 1 statics
    if(!xpfile[message.author.id]) {
        xpfile[message.author.id] = {
           xp: 0,
           level: 1,
           reqxp: 50
        }
// catch errors
       fs.writeFile("./xp.json",JSON.stringify(xpfile),function(err){ 
        if(err) console.log(err)
       })
    }

    xpfile[message.author.id].xp += addXP

    if(xpfile[message.author.id].xp > xpfile[message.author.id].reqxp){
        xpfile[message.author.id].xp -= xpfile[message.author.id].reqxp // it will subtrsct xp whenever u pass a lvl
        xpfile[message.author.id].reqxp *= 2 // XP you need to increase if level 1 is 100 xp so lvl 2 will 200 xp (multiplied by 2 [   .reqxp *= 2  ])
        xpfile[message.author.id].reqxp = Math.floor(xpfile[message.author.id].reqxp) // XP Round
        xpfile[message.author.id].level += 1 // it add 1 level when u level up

// this code will send (" you are now level [your lvl]!") then it will delete it after 10 seconds        
        message.reply("You Are Now Level **"+xpfile[message.author.id].level+"**!").then( 
            msg=>msg.delete({timeout: "10m"})
        )

		} fs.writeFile("./xp.json",JSON.stringify(xpfile),function(err){
        if(err) console/log(err)
    })

    //if someone typed in chat =level it will make a embed 
    if(message.content.startsWith("glevel")){
        let user = message.mentions.users.first() || message.author

        let embed = new Discord.MessageEmbed()
        .setTitle("Level Card")
        .setColor("RANDOM")
        .addField("Level: ",xpfile[user.id].level)
        .addField("XP: ", xpfile[user.id].xp+"/"+xpfile[user.id].reqxp)
        .addField("XP Required: ",xpfile[user.id].reqxp)
        message.channel.send(embed)
    
		
		}  if (message.content === `${prefix}severs`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('the best severs to join')

      .setDescription('severs to join')
      .addFields(
        { name: 'SHADOW GAMES', value: 'https://discord.gg/AhE3pkBC5k' },
      )
      .addFields(
        { name: 'WAFFLES NATION', value: 'https://discord.gg/jRp8EUVsCY' },
      )
.addFields(
        { name: 'GLITCH GAMES', value: 'https://discord.gg/6v9XNXqRuh' },
      )



 message.channel.send(newEmbed);

		} if (message.content === `${prefix}help unity`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle(' my unity commands')

      .setDescription('gseverinfo \nguserinfo\nlevel\ngsevers\ngwhois')

message.channel.send(newEmbed);

		} if (message.content === `${prefix}bal`) {
    client.commands.get('bal').execute(client, message, args );

	} 








































});
keepAlive();
client.login('Nzg3Mzk2NzkyMzUwMDE1NTA4.X9UWaA.574GC0RnzHE0LAcxiiiMtLDz-pA');