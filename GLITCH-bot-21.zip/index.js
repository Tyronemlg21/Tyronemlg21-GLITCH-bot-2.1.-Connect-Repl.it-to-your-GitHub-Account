const Discord = require('discord.js');
const client = new Discord.Client();
const keepAlive = require('./server.js');
const prefix = 'g';
const fs = require('fs');

client.commands = new Discord.Collection();

const commandFiles = fs
  .readdirSync('./commands')
  .filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.name, command);
}

client.on('ready', () => {
  console.log('I\'m good now');

  client.user.setPresence({ activity: { name: 'with discord.js' }, status: 'dnd' })
    .then(console.log)
    .catch(console.error);
  client.user.setActivity('ghelp', { type: 'WATCHING' })
    .then(presence => console.log(`Activity set to ${presence.activities[0].name}`))
    .catch(console.error);
  client.user.setUsername('GLITCH BOT')
    .then(user => console.log(`My new username is ${user.username}`))
    .catch(console.error);

});

client.on('message', message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'ping') {
    client.commands.get('ping').execute(message, args);
  } else if (command === 'beep') {
    client.commands.get('beep').execute(message, args);
  } else if (message.content === `${prefix}server`) {
    client.commands.get('server').execute(message, args);
  } else if (message.content === `${prefix}userinfo`) {
    client.commands.get('userinfo').execute(message, args);
  } else if (message.content === `${prefix}react`) {
    message.react('😎');
    message.react('😀');
  } else if (message.content === `${prefix}cry`) {
    client.commands.get('cry').execute(message, args);
  } else if (message.content === `${prefix}bot`) {
    message.channel.send('??? who is the? i know its not me? or im a bot? 😵');
  } else if (message.content === `${prefix}bot help`) {
    message.channel.send('https://discord.gg/xvUDdTSyxr');
  } else if (message.content === `${prefix}hack`) {
    const taggedUser = message.mentions.users.filter();

    message.channel.send(
      `hacking: ${taggedUser.username} sorry GLITCH bot.exe has stop working`
    );
  }
  if (message.content === `${prefix}help`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('my help commands')

      .setDescription(
        'my help commands are  \nghelp mod  \nghelp fun   \nghelp unity  '
      )


    message.channel.send(newEmbed);
  } if (message.content === `${prefix}help mod`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('Sorry i dont have any mod commands right now')

      .setDescription('|')

    message.channel.send(newEmbed);

  } if (message.content === `${prefix}help fun`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle(' my fun commands')

      .setDescription('gping \ngbeep \ngcry \nghack \ngreact \ngbot\ngmilk')

    message.channel.send(newEmbed);


  } if (message.content === `${prefix}help unity`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('unity commands')

      .setDescription('gserver and guserinfo')
      .addFields(
        { name: '|', value: '|' },


      )

    message.channel.send(newEmbed);

  } if (message.content === `${prefix}faq1`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('who made me?')

      .setDescription('TYRONEMLG YT made me and he got from someone namd waffle and bob is real')
      .setFooter('give credit to waffle to help me with the embed code')

    message.channel.send(newEmbed);

  } if (message.content === `${prefix}faq2`) {
    const newEmbed = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setTitle('why dose it has so little commands for the bot')

      .setDescription('the developer of the bot is to new to coding \nso he is learning more code \nto make more cool commands')



    message.channel.send(newEmbed);

  } if (command === 'milk') {
    client.commands.get('milk').execute(message, args);
  }


    



























});
keepAlive();
client.login('Nzg3Mzk2NzkyMzUwMDE1NTA4.X9UWaA.574GC0RnzHE0LAcxiiiMtLDz-pA');
