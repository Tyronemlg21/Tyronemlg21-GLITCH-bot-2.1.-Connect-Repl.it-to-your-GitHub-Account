module.exports = {
	name: 'userinfo',
	description: 'identifies the user who use this command',
	execute(message, args) {
		message.channel.send(`Your username: ${message.author.username}\nYour ID: ${message.author.id}`);
	},
};
