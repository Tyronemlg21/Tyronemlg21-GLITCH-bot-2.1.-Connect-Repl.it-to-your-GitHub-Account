module.exports = {
	name: 'ran',
	description: 'gess a number',
	execute(message, args) {

if (!args.length || !args[1]) {
message.channel.send('you need to type in min and mak values like this \ `grandom  10 5\` ')
}

else {

  let max = args[0]
  let min = args[1]


let randNo = Math.round(Math.random() *max + min)

const embed = new Discord.MessageEmbed()
.setTitle('you randome number is: ')
.setDescription('randNo')
.setColor('RANDOM')
.setFooter('Random Number Generator')
.setTimeStamp()

message.reply(embed)

}



	
	},
};