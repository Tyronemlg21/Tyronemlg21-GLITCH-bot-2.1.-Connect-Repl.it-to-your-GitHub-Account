module.exports = {
	name: 'cry',
	description: 'u will make the bot cry why',
	execute(message, args) {
		message.channel.send(` don't cry u will make me cry😭😭`);
	},
};