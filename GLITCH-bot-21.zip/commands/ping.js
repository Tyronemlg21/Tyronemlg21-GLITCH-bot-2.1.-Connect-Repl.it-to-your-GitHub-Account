module.exports = {
	name: 'ping',
	description: 'Ping!',
	execute(message, args) {
		message.channel.send('Pong. \nwow that far like 5m thats');
		 
	},
	
};
