const express = require('express');
const server = express();



server.all('/', (req, res)=>{
    res.send(`glitch bot stats  : \n(online)\n you have now enter the glitch bot website as you can see it has notting rith now .\n\nThe Devloper is tell working on some cool new commands and he is trying to make a econamysystem.\n this weill soon be the GLITCH BOT DACHBORAD as for now I will see you soon ween this get updated or a new and cooler website opens`)
	
})
function keepAlive(){
    server.listen(3000, ()=>{console.log("Server is Ready!")});
}
module.exports = keepAlive;
